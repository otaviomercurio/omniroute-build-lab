"""Manual public CI recipe. Standard library only; never import project code."""
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import urllib.request
import zipfile

RECIPE = Path(__file__).resolve().parents[1]
CONFIG = json.loads((RECIPE / 'build-inputs.json').read_text())

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def save(path, value):
    with open(path, 'x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def download(url, dest, expected, maximum):
    # URLs and immutable digests come only from the reviewed recipe, never inputs.
    h, size = hashlib.sha256(), 0
    with urllib.request.urlopen(url, timeout=60) as response, open(dest, 'xb') as out:
        if response.geturl() != url:
            raise RuntimeError('Unexpected download redirect')
        while True:
            block = response.read(1024*1024)
            if not block:
                break
            size += len(block)
            if size > maximum:
                raise RuntimeError('Download size bound exceeded')
            h.update(block)
            out.write(block)
    if h.hexdigest() != expected:
        raise RuntimeError('Pinned download SHA256 mismatch')
    return size

def extract(archive, target, root, max_files, max_bytes):
    if target.exists():
        raise RuntimeError('Fresh extraction root required')
    seen, entries, total = set(), [], 0
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            parts = item.filename.rstrip('/').split('/')
            if '\\' in item.filename or not parts or parts[0] != root:
                raise RuntimeError('Unexpected archive root/path')
            for part in parts:
                if part in ('','.','..') or re.search(r'[<>:"|?*\x00-\x1f]', part) or part.endswith((' ','.')) or re.match(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)', part, re.I):
                    raise RuntimeError('Unsafe archive path')
            if item.flag_bits & 1 or stat.S_ISLNK(item.external_attr >> 16):
                raise RuntimeError('Encrypted/link entry rejected')
            if len(parts) == 1:
                continue
            rel = '/'.join(parts[1:])
            if rel.casefold() in seen:
                raise RuntimeError('Archive path collision')
            seen.add(rel.casefold())
            if not item.is_dir():
                entries.append((item, rel)); total += item.file_size
        if len(entries) > max_files or total > max_bytes:
            raise RuntimeError('Archive expansion bound exceeded')
        target.mkdir()
        for item, rel in entries:
            out = (target / rel).resolve()
            if not out.is_relative_to(target):
                raise RuntimeError('Extraction escaped root')
            out.parent.mkdir(parents=True, exist_ok=True)
            with z.open(item) as src, open(out, 'xb') as dst:
                while True:
                    block = src.read(1024*1024)
                    if not block: break
                    dst.write(block)
        return len(entries), total

def patch(cwd, name):
    patch_file = RECIPE / 'patches' / name
    if sha(patch_file) != CONFIG['patches'][name]:
        raise RuntimeError('Patch SHA mismatch')
    args = ['git','-c','core.autocrlf=false','-c','core.eol=lf','apply','--whitespace=nowarn']
    subprocess.run(args+['--check',str(patch_file)],cwd=cwd,check=True)
    subprocess.run(args+[str(patch_file)],cwd=cwd,check=True)
    subprocess.run(args+['--reverse','--check',str(patch_file)],cwd=cwd,check=True)

def verify(source, temporary):
    for entry in CONFIG['changedSources']:
        if sha(source / entry['path']) != entry['sha256']:
            raise RuntimeError('Changed source or lock drift: '+entry['path'])
    for name, expected in CONFIG['preservedSources'].items():
        if sha(source / name) != expected:
            raise RuntimeError('Preserved source drift: '+name)
    original = json.loads((temporary/'source-preservation.json').read_text())
    for name, expected in original['dashboardAndInstrumentation'].items():
        if sha(source / name) != expected:
            raise RuntimeError('Dashboard/instrumentation source changed: '+name)
    lock = json.loads((source/'package-lock.json').read_text())
    libc = {k:v['libc'] for k,v in lock['packages'].items() if 'libc' in v}
    if len(libc) != 71 or libc != original['libc']:
        raise RuntimeError('libc metadata lost or changed')
    braces = lock['packages']['node_modules/braces']
    if braces['resolved'] != CONFIG['bracesResolved'] or braces['integrity'] != CONFIG['bracesIntegrity']:
        raise RuntimeError('Pinned braces dependency drift')
    if (source/'node_modules').exists():
        for name, expected in {'next':'16.3.8','dompurify':'3.4.16','smol-toml':'1.9.1','katex':'0.18.10','braces':'3.0.4'}.items():
            installed=json.loads((source/'node_modules'/name/'package.json').read_text())
            if installed['version'] != expected:
                raise RuntimeError('Installed hardened dependency version differs: '+name)

def prepare(temp, source):
    node_zip = temp/'omniroute-node.zip'
    download(CONFIG['nodeArchiveUrl'],node_zip,CONFIG['nodeArchiveSha256'],100*1024*1024)
    extract(node_zip,temp/'omniroute-node','node-v24.21.0-win-x64',20000,400*1024*1024)
    source_zip = temp/'omniroute-upstream.zip'
    count = download(CONFIG['upstreamArchiveUrl'],source_zip,CONFIG['upstreamArchiveSha256'],300*1024*1024)
    if count != CONFIG['upstreamArchiveBytes']:
        raise RuntimeError('Pinned upstream size mismatch')
    files, size = extract(source_zip,source,CONFIG['upstreamRoot'],30000,800*1024*1024)
    if files != CONFIG['sourceFileCount'] or size != CONFIG['sourceExpandedBytes']:
        raise RuntimeError('Pinned source inventory mismatch')
    for entry in CONFIG['changedSources']:
        if sha(source / entry['path']) != entry['archiveSha256']:
            raise RuntimeError('Patch preimage differs')
    lock = json.loads((source/'package-lock.json').read_text())
    preserved = {}
    for file in source.rglob('*'):
        if file.is_file():
            rel = file.relative_to(source).as_posix()
            if rel.startswith('src/app/') and ('dashboard' in rel or rel.endswith(('layout.tsx','page.tsx'))) or rel.startswith('src/instrumentation'):
                preserved[rel] = sha(file)
    save(temp/'source-preservation.json',{'dashboardAndInstrumentation':preserved,'libc':{k:v['libc'] for k,v in lock['packages'].items() if 'libc' in v}})
    for name in ('correcao-nolog.patch','package-hardening.patch','package-lock.minimal.patch'):
        patch(source,name)
    verify(source,temp)

def guard(source,temp):
    verify(source,temp)
    package = json.loads((source/'node_modules/braces/package.json').read_text())
    if package['version'] != '3.0.4':
        raise RuntimeError('Unexpected installed braces version')
    for entry in CONFIG['guardPreimages']:
        if sha(source/'node_modules'/entry['path']) != entry['sha256']:
            raise RuntimeError('Actual fork bytes differ from reviewed guard preimage')
    if (source/'node_modules/braces/lib/assert-safe-ast.js').exists():
        raise RuntimeError('Guard unexpectedly present before patch')
    patch(source/'node_modules','braces-reference-versus-fork.patch')
    for entry in CONFIG['guardFiles']:
        if sha(source/'node_modules'/entry['path']) != entry['sha256']:
            raise RuntimeError('Guard final bytes differ')

def verify_outputs(source, dist):
    # Presence/byte gates, not a claim of runtime acceptance. Upstream prepublish
    # catches some compiler errors, so exit zero alone is insufficient.
    required = [
        'server.js','server-ws.mjs','BUILD_SHA','http-method-guard.cjs',
        '.build/next/server/app-paths-manifest.json','.build/next/server/instrumentation.js',
        'open-sse/mcp-server/server.js',
        'open-sse/vendor/codex-chatgpt-web/adapters/chatgpt-web/mcp-server.js',
        'src/lib/db/healthCheckWorker.js','src/lib/usage/callLogArtifactWorker.js',
        'open-sse/services/compression/compressionWorker.js',
        'open-sse/services/compression/engines/llmlingua/onnxWorker.js',
    ]
    for name in required:
        if not (dist/name).is_file() or (dist/name).stat().st_size == 0:
            raise RuntimeError('Required staged output missing: '+name)
    mitm_count = 0
    for original in (source/'src/mitm').rglob('*.ts'):
        if original.name.endswith('.d.ts'): continue
        target=dist/original.relative_to(source).with_suffix('.js')
        if not target.is_file() or target.stat().st_size == 0:
            raise RuntimeError('Compiled MITM output missing; source fallback rejected')
        mitm_count += 1
    if not mitm_count: raise RuntimeError('MITM compiler input inventory absent')
    asset_count=0
    for name in ('public','.build/next/static'):
        originals=[f for f in (source/name).rglob('*') if f.is_file()]
        if not originals: raise RuntimeError('Static/public output inventory empty: '+name)
        for original in originals:
            target=dist/original.relative_to(source)
            if not target.is_file() or sha(target)!=sha(original):
                raise RuntimeError('Staged static/public asset absent or changed')
            asset_count += 1
    # Windows-specific packages/paths, then exact bytes relative to this Windows
    # install. ABI load and provider behavior remain separate acceptance work.
    native_groups = [
        ('node_modules/better-sqlite3','*.node'),
        ('node_modules/onnxruntime-node/bin/napi-v6/win32/x64','*.node'),
        ('node_modules/onnxruntime-node/bin/napi-v6/win32/x64','*.dll'),
        ('node_modules/@wreq-js/binding-win32-x64-msvc','*.node'),
        ('node_modules/sqlite-vec-windows-x64','*.dll'),
    ]
    native_count=0
    for name, pattern in native_groups:
        originals=[f for f in (source/name).rglob(pattern) if f.is_file()]
        if not originals: raise RuntimeError('Required Windows native output absent: '+name)
        for original in originals:
            target=dist/original.relative_to(source)
            if not target.is_file() or sha(target)!=sha(original):
                raise RuntimeError('Staged Windows native bytes absent or changed')
            native_count += 1
    return {'requiredOutputs':len(required),'compiledMitmOutputs':mitm_count,'staticAssetsByteVerified':asset_count,'nativeFilesByteVerified':native_count,'runtimeLoadAcceptance':'PENDING'}

def package(source,temp):
    verify(source,temp)
    dist = source/'dist'
    output_checks = verify_outputs(source,dist)
    routes = json.loads((dist/'.build/next/server/app-paths-manifest.json').read_text())
    if not any('/dashboard/' in k for k in routes) or '/api/v1/images/edits/route' not in routes:
        raise RuntimeError('Dashboard or edits route missing from compiled app')
    for entry in CONFIG['guardFiles']:
        if sha(source/'node_modules'/entry['path']) != entry['sha256']:
            raise RuntimeError('Installed guard changed during build')
    out = temp/'omniroute-lab-output'
    out.mkdir()
    files=[]; guard_copies=[]
    for f in sorted(dist.rglob('*')):
        if f.is_symlink(): raise RuntimeError('Unmaterialized runtime symlink')
        if not f.is_file(): continue
        rel=f.relative_to(dist).as_posix()
        if f.name == '.env' or f.suffix.lower() in ('.db','.sqlite','.sqlite3','.log') or f.name.endswith(('-wal','-shm')):
            raise RuntimeError('Runtime data or environment file unexpectedly staged')
        files.append({'path':'dist/'+rel,'bytes':f.stat().st_size,'sha256':sha(f)})
        if rel.endswith('/braces/lib/assert-safe-ast.js'):
            package_root=f.parent.parent
            for entry in CONFIG['guardFiles']:
                local=package_root/entry['path'].split('braces/',1)[1]
                if sha(local)!=entry['sha256']:raise RuntimeError('Staged guard bytes differ')
            guard_copies.append(rel)
    archive=out/'runtime-win-x64.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for entry in files:z.write(source/entry['path'],entry['path'])
        z.write(source/'LICENSE','UPSTREAM-LICENSE')
        z.write(RECIPE/'LICENSE','RECIPE-LICENSE')
        z.write(RECIPE/'NOTICE','NOTICE')
    if archive.stat().st_size>CONFIG['maxReleaseAssetBytes']:
        raise RuntimeError('ZIP too large for one release asset; no automatic split/upload')
    for name, origin in [('UPSTREAM-LICENSE',source/'LICENSE'),('RECIPE-LICENSE',RECIPE/'LICENSE'),('NOTICE',RECIPE/'NOTICE')]:
        files.append({'path':name,'bytes':origin.stat().st_size,'sha256':sha(origin)})
    save(out/'runtime-files.json',files)
    node=temp/'omniroute-node/node.exe'
    versions=json.loads(subprocess.check_output([str(node),'-p','JSON.stringify(process.versions)'],text=True))
    provenance={'classification':'LAB_BUILD_NOT_APPROVED_FOR_DEPLOYMENT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstreamCommit':CONFIG['upstreamCommit'],'upstreamZipSha256':CONFIG['upstreamArchiveSha256'],'recipeCommit':os.environ['GITHUB_SHA'],'patches':CONFIG['patches'],'nodeArchiveSha256':CONFIG['nodeArchiveSha256'],'nodeSignatureVerified':False,'toolchain':versions,'runnerImageOS':os.environ.get('ImageOS'),'runnerImageVersion':os.environ.get('ImageVersion'),'runId':os.environ['GITHUB_RUN_ID'],'runAttempt':os.environ['GITHUB_RUN_ATTEMPT'],'npmVersion':subprocess.check_output([str(node),str(temp/'omniroute-node/node_modules/npm/bin/npm-cli.js'),'--version'],text=True).strip(),'installedLockBytePreserved':True,'libcFieldsPreserved':71,'dashboardSourcesUnchanged':True,'instrumentationSourcesUnchanged':True,'installedGuardVerified':True,'unminifiedStagedGuardCopiesVerified':guard_copies,'bundleBehaviorAcceptance':'PENDING','runtimeCompatibilityOnDestination':'PENDING','signedAttestation':False,'buildMode':'full webpack standalone and official build:cli, no graph reduction'}
    provenance['outputPresenceAndByteGates']=output_checks
    save(out/'provenance.json',provenance)
    with open(out/'SHA256SUMS.txt','x',encoding='ascii',newline='\n') as f:
        for name in ('runtime-win-x64.zip','runtime-files.json','provenance.json'):
            f.write(sha(out/name)+'  '+name+'\n')
    print(json.dumps({'classification':provenance['classification'],'archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'stagedGuardCopies':len(guard_copies),'bundleBehaviorAcceptance':'PENDING'}))

def main():
    if len(sys.argv)!=3 or os.environ.get('GITHUB_ACTIONS')!='true' or os.environ.get('GITHUB_EVENT_NAME')!='workflow_dispatch':
        raise RuntimeError('Manual GitHub job only; not a local installer')
    temp=Path(sys.argv[2]).resolve()
    if temp!=Path(os.environ['RUNNER_TEMP']).resolve():raise RuntimeError('Wrong scratch root')
    source=temp/'omniroute-build-source'
    stages={'prepare':lambda:prepare(temp,source),'guard':lambda:guard(source,temp),'verify':lambda:verify(source,temp),'package':lambda:package(source,temp)}
    if sys.argv[1] not in stages:raise RuntimeError('Unknown stage')
    stages[sys.argv[1]]()

if __name__=='__main__':main()
