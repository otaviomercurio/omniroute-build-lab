// Structural/byte verification only. Never load MITM, database or certificate code.
const fs = require('node:fs');
const path = require('node:path');
const { createRequire, builtinModules } = require('node:module');
const { createHash } = require('node:crypto');

const CJS = ['server.cjs', '_internal/aliasConfig.cjs', '_internal/bypass.cjs',
  '_internal/forwardTarget.cjs', '_internal/ingest.cjs', '_internal/rootCaShim.cjs',
  '_internal/standaloneRouting.cjs', '_internal/writeBackpressure.cjs'];
const ROUTES = ['/api/cli-tools/antigravity-mitm/route', '/api/tools/agent-bridge/server/route',
  '/api/tools/agent-bridge/cert/route', '/api/settings/mitm/route',
  '/(dashboard)/dashboard/system/mitm-proxy/page'];
const hash = b => createHash('sha256').update(b).digest('hex');
const inside = (root, file) => { const rel = path.relative(root, file); return rel && !rel.startsWith('..') && !path.isAbsolute(rel); };
function check(value, code) { if (!value) throw new Error(code); }
function fileBytes(file) {
  check(fs.existsSync(file) && fs.statSync(file).isFile() && !fs.lstatSync(file).isSymbolicLink(), 'MITM_FILE_MISSING_OR_LINK');
  const b = fs.readFileSync(file); check(b.length > 0, 'MITM_FILE_EMPTY'); return b;
}
function equalFile(original, staged) {
  const a = fileBytes(original), b = fileBytes(staged);
  check(hash(a) === hash(b), 'MITM_STAGED_BYTES_DIFFER');
}
function imports(parser, file) {
  const ast = parser.parse(fileBytes(file).toString('utf8'), { sourceType: 'unambiguous' });
  const result = [];
  function visit(node) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'CallExpression' && (node.callee?.type === 'Import' ||
      (node.callee?.type === 'Identifier' && node.callee.name === 'require'))) {
      check(node.arguments.length === 1 && node.arguments[0].type === 'StringLiteral', 'MITM_NONLITERAL_IMPORT_REQUIRES_REVIEW');
      result.push({ name: node.arguments[0].value, dynamicImport: node.callee.type === 'Import' });
    }
    if (node.type === 'ImportExpression') {
      check(node.source?.type === 'StringLiteral', 'MITM_NONLITERAL_IMPORT_REQUIRES_REVIEW');
      result.push({ name: node.source.value, dynamicImport: true });
    }
    for (const [key, value] of Object.entries(node)) {
      if (key === 'loc' || key === 'tokens' || key === 'comments') continue;
      if (Array.isArray(value)) value.forEach(visit); else if (value && typeof value === 'object') visit(value);
    }
  }
  visit(ast.program); return result;
}
function packageRoot(entry, bound) {
  let dir = path.dirname(entry);
  while (inside(bound, dir)) {
    const manifest = path.join(dir, 'package.json');
    // Nested {"type":"commonjs"} markers are not package roots.
    if (fs.existsSync(manifest) && typeof JSON.parse(fileBytes(manifest)).name === 'string') return dir;
    dir = path.dirname(dir);
  }
  throw new Error('MITM_DEPENDENCY_PACKAGE_ROOT_MISSING');
}
function resolveEntry(from, specifier, bound) {
  let entry;
  try { entry = fs.realpathSync(createRequire(from).resolve(specifier)); }
  catch { throw new Error('MITM_IMPORT_UNRESOLVED'); }
  check(inside(bound, entry), 'MITM_IMPORT_ESCAPED_BUNDLE'); return entry;
}
function verifyMitmRuntime(sourceArg, distArg, parser) {
  const source = fs.realpathSync(sourceArg), dist = fs.realpathSync(distArg);
  check(source !== dist, 'MITM_DIST_MUST_BE_SEPARATE');
  const srcMitm = path.join(source, 'src/mitm'), dstMitm = path.join(dist, 'src/mitm');
  const builtins = new Set(builtinModules.map(n => n.replace(/^node:/, '')));
  const reached = new Set(), dependencies = [], imported = new Set();
  let edges = 0;
  function follow(rel) {
    check(CJS.includes(rel), 'MITM_UNREVIEWED_LOCAL_IMPORT');
    if (reached.has(rel)) return;
    reached.add(rel);
    const original = path.join(srcMitm, rel), staged = path.join(dstMitm, rel);
    equalFile(original, staged);
    for (const item of imports(parser, original)) {
      if (builtins.has(item.name.replace(/^node:/, ''))) continue;
      const a = resolveEntry(original, item.name, source), b = resolveEntry(staged, item.name, dist);
      equalFile(a, b);
      if (item.name.startsWith('.')) {
        const child = path.relative(srcMitm, a).replaceAll(path.sep, '/');
        check(path.relative(dstMitm, b).replaceAll(path.sep, '/') === child, 'MITM_IMPORT_RESOLUTION_DIFFERED');
        edges++; follow(child);
      } else {
        check(['selfsigned', 'better-sqlite3'].includes(item.name), 'MITM_UNREVIEWED_EXTERNAL_IMPORT');
        // selfsigned uses main (no conditional exports), so import() and require
        // resolve the same CJS entry. Refuse a changed export contract.
        const pkg = JSON.parse(fileBytes(path.join(packageRoot(a, source), 'package.json')));
        if (item.dynamicImport) check(item.name === 'selfsigned' && !pkg.exports && pkg.main === 'index.js' && pkg.type !== 'module', 'MITM_DYNAMIC_EXPORT_CONTRACT_CHANGED');
        imported.add(item.name); dependencies.push([a, b]);
      }
    }
  }
  follow('server.cjs');
  check(reached.size === CJS.length && edges === CJS.length - 1, 'MITM_CJS_CLOSURE_INCOMPLETE');
  check(imported.has('selfsigned') && imported.has('better-sqlite3'), 'MITM_EXTERNAL_IMPORT_CONTRACT_CHANGED');

  // Verify the package entries and required dependency manifests reachable from
  // these actual imports. This resolves files, but does not require/import them.
  const packages = new Set(); let packageEntries = 0;
  while (dependencies.length) {
    const [a, b] = dependencies.pop();
    const ar = packageRoot(a, source), br = packageRoot(b, dist);
    if (packages.has(ar)) continue;
    check(packages.size < 64, 'MITM_DEPENDENCY_BOUND_EXCEEDED'); packages.add(ar);
    equalFile(a, b); equalFile(path.join(ar, 'package.json'), path.join(br, 'package.json'));
    for (let dir = path.dirname(a); inside(ar, dir); dir = path.dirname(dir)) {
      const rel = path.relative(ar, dir), originalScope = path.join(dir, 'package.json'), stagedScope = path.join(br, rel, 'package.json');
      if (fs.existsSync(originalScope) || fs.existsSync(stagedScope)) equalFile(originalScope, stagedScope);
    }
    const pkg = JSON.parse(fileBytes(path.join(ar, 'package.json'))); packageEntries++;
    for (const dep of Object.keys(pkg.dependencies ?? {})) {
      const nextA = resolveEntry(a, dep, source), nextB = resolveEntry(b, dep, dist);
      dependencies.push([nextA, nextB]);
    }
  }
  const srcNext = path.join(source, '.build/next/server'), dstNext = path.join(dist, '.build/next/server');
  const manifest = JSON.parse(fileBytes(path.join(dstNext, 'app-paths-manifest.json')));
  const builtManifest = JSON.parse(fileBytes(path.join(srcNext, 'app-paths-manifest.json')));
  for (const route of ROUTES) {
    const rel = manifest[route]; check(typeof rel === 'string' && rel.endsWith('.js'), 'MITM_NEXT_ENTRY_MISSING');
    const a = path.resolve(srcNext, rel), b = path.resolve(dstNext, rel);
    check(inside(srcNext, a) && inside(dstNext, b), 'MITM_NEXT_ENTRY_ESCAPE');
    check(builtManifest[route] === rel, 'MITM_NEXT_MANIFEST_DIFFERS');
    fileBytes(a);
    // The official assembler sanitizes paths and patches chunk references, so
    // post-assembly Next bytes need not equal the pre-assembly compiler output.
    try { parser.parse(fileBytes(b).toString('utf8'), { sourceType: 'unambiguous' }); }
    catch (error) { if (error.message?.startsWith('MITM_')) throw error; throw new Error('MITM_NEXT_SYNTAX_INVALID'); }
  }
  return { contract: 'Next-compiled management plus standalone CJS child', cjsFilesByteVerified: reached.size,
    relativeImportsResolved: edges, externalImportsResolved: [...imported].sort(), dependencyPackageEntriesByteVerified: packageEntries,
    nextEntrypointsPresentAndParsed: ROUTES.length, nextEntrypointBehavior: 'NOT_EXECUTED', auxiliaryTypeScriptCompilerFixed: false,
    auxiliaryTypeScriptWarning: 'Upstream optional per-file MITM tsc can fail and copy TS. Per-file JS is not consumed by the reviewed standalone path; compiler diagnostics remain visible.',
    runtimeAcceptance: 'PENDING_NOT_STARTED' };
}
module.exports = { verifyMitmRuntime, CJS, ROUTES };
if (require.main === module) {
  const [source, dist] = process.argv.slice(2);
  check(process.env.GITHUB_ACTIONS === 'true' && source && dist && process.argv.length === 4, 'MANUAL_CI_VERIFICATION_ONLY');
  const parser = createRequire(path.join(path.resolve(source), 'package.json'))('@babel/parser');
  process.stdout.write(JSON.stringify(verifyMitmRuntime(source, dist, parser)) + '\n');
}
