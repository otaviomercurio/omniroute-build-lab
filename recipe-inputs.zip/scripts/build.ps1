$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($env:GITHUB_ACTIONS -ne 'true' -or $env:RUNNER_OS -ne 'Windows' -or $env:GITHUB_EVENT_NAME -ne 'workflow_dispatch') { throw 'Only the approved manual Windows GitHub job is supported' }
$eventData = Get-Content -Raw -LiteralPath $env:GITHUB_EVENT_PATH | ConvertFrom-Json
if ($eventData.repository.private -ne $false -or $eventData.inputs.approve_public_lab_draft -notin @('true',$true)) { throw 'Public repository and explicit draft approval required' }
if ($env:GH_TOKEN -or $env:GITHUB_TOKEN) { throw 'Do not expose repository credentials to the build' }
$recipeRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$config = Get-Content -Raw -LiteralPath (Join-Path $recipeRoot 'build-inputs.json') | ConvertFrom-Json
$sourceRoot = Join-Path $env:RUNNER_TEMP 'omniroute-build-source'
$outputRoot = Join-Path $env:RUNNER_TEMP 'omniroute-lab-output'
$helper = Join-Path $PSScriptRoot 'recipe.py'
function Assert-Resources {
  param(
    [string]$Stage,
    [int]$DiskGiB,
    [object]$Configuration = $config,
    [scriptblock]$Sample = {
      $system = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 3
      $drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($env:RUNNER_TEMP))
      [pscustomobject]@{totalBytes=[double]$system.TotalVisibleMemorySize*1KB;availableBytes=[double]$system.FreePhysicalMemory*1KB;freeDiskBytes=$drive.AvailableFreeSpace;cpuCount=[Environment]::ProcessorCount}
    },
    [scriptblock]$Clock = { [Diagnostics.Stopwatch]::GetTimestamp() / [double][Diagnostics.Stopwatch]::Frequency },
    [scriptblock]$Pause = { param([int]$Milliseconds) Start-Sleep -Milliseconds $Milliseconds },
    [scriptblock]$Emit = { param($Row) Write-Output ($Row | ConvertTo-Json -Compress) }
  )
  # Only this admission observation is repeated. Installation/build never retry.
  # Same resource minima; accept three consecutive measurements five seconds apart.
  $started = [double](& $Clock)
  $consecutive = 0
  for ($attempt = 1; $attempt -le 13; $attempt++) {
    # Reserve the bounded CIM operation's three seconds inside the observation window.
    if (([double](& $Clock) - $started) -gt 57) { break }
    $sampleRow = & $Sample
    foreach ($name in @('totalBytes','availableBytes','freeDiskBytes','cpuCount')) {
      $value = $sampleRow.$name
      if ($null -eq $value -or [double]::IsNaN([double]$value) -or [double]::IsInfinity([double]$value) -or [double]$value -lt 0) { throw 'Resource measurement invalid; admission denied' }
    }
    $elapsed = [double](& $Clock) - $started
    $hardFailure = $sampleRow.totalBytes -lt $Configuration.minTotalMemoryGiB*1GB -or $sampleRow.freeDiskBytes -lt $DiskGiB*1GB -or $sampleRow.cpuCount -lt 4
    if ($sampleRow.availableBytes -ge $Configuration.minAvailableMemoryGiB*1GB) { $consecutive++ } else { $consecutive=0 }
    $row = [ordered]@{stage=$Stage;utc=[DateTime]::UtcNow.ToString('o');totalBytes=$sampleRow.totalBytes;availableBytes=$sampleRow.availableBytes;freeDiskBytes=$sampleRow.freeDiskBytes;cpuCount=$sampleRow.cpuCount;attempt=$attempt;consecutiveAdequate=$consecutive;elapsedSeconds=[Math]::Round($elapsed,3);requiredAvailableBytes=$Configuration.minAvailableMemoryGiB*1GB;hardFailure=$hardFailure}
    & $Emit $row
    if ($hardFailure) { throw 'Physical resource admission failed (total RAM, CPU or disk); no build started' }
    if ($elapsed -lt 0 -or $elapsed -gt 60) { break }
    if ($consecutive -ge 3) { return }
    if ($attempt -eq 13 -or $elapsed -ge 60) { break }
    $remainingMs = [Math]::Floor((60 - $elapsed)*1000)
    if ($remainingMs -lt 5000) { break }
    & $Pause 5000
  }
  throw 'Available memory did not stabilize above the unchanged minimum within 60 seconds; admission denied, no build retry'
}
function Invoke-Checked([string]$Command,[string[]]$Arguments) {
  & $Command @Arguments
  if ($LASTEXITCODE -ne 0) { throw "Required command failed: $Command" }
}
Assert-Resources 'before-download-install' $config.minInitialDiskGiB
Invoke-Checked 'python' @($helper,'prepare',$env:RUNNER_TEMP)
$nodeRoot = Join-Path $env:RUNNER_TEMP 'omniroute-node'
$node = Join-Path $nodeRoot 'node.exe'
$npm = Join-Path $nodeRoot 'node_modules/npm/bin/npm-cli.js'
$env:PATH = "$nodeRoot;$env:PATH"
Invoke-Checked $node @('-e',"if(process.version!=='v24.21.0'||process.platform!=='win32'||process.arch!=='x64')process.exit(1);console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch,abi:process.versions.modules}))")
$env:HUSKY = '0'
$env:CI = '1'
$env:NEXT_TELEMETRY_DISABLED = '1'
$env:PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = '1'
$env:ELECTRON_SKIP_BINARY_DOWNLOAD = '1'
$env:npm_config_cache = Join-Path $env:RUNNER_TEMP 'npm-transient-cache'
$env:npm_config_fetch_retries = '1'
$env:npm_config_fetch_timeout = '60000'
$env:DATA_DIR = Join-Path $env:RUNNER_TEMP 'omniroute-empty-build-data'
$env:DISABLE_SQLITE_AUTO_BACKUP = 'true'
$env:OMNIROUTE_BUILDING = '1'
$env:OMNIROUTE_USE_TURBOPACK = '0'
$env:OMNIROUTE_BUILD_MEMORY_MB = '8192'
$env:NODE_OPTIONS = '--max-old-space-size=8192'
$env:OMNIROUTE_BUILD_SHA = 'c1e30b7'
# Public, nonproduction build placeholder; no runtime credentials are supplied.
$env:JWT_SECRET = 'public-build-placeholder-not-a-runtime-authentication-secret'
foreach ($flag in @('OMNIROUTE_BUILD_PROFILE','OMNIROUTE_BUILD_BACKEND_ONLY','OMNIROUTE_SKIP_STANDALONE','OMNIROUTE_SKIP_NATIVE_DEP_CHECK','OMNIROUTE_MITM_STUB','NEXT_DIST_DIR')) {
  if ([Environment]::GetEnvironmentVariable($flag)) { throw "Unexpected build scope override: $flag" }
}
Push-Location $sourceRoot
try {
  Invoke-Checked $node @($npm,'ci','--include=dev','--legacy-peer-deps','--no-audit','--no-fund','--foreground-scripts')
  Invoke-Checked 'python' @($helper,'guard',$env:RUNNER_TEMP)
  Invoke-Checked $node @($npm,'run','check:native-deps')
  Invoke-Checked $node @('-e',"const D=require('better-sqlite3');const d=new D(':memory:');if(d.prepare('select 1 as ok').get().ok!==1)process.exit(1);d.close();console.log('native SQLite memory-only smoke passed')")
  # Preinstall the independently locked plugin so prepublish.ts does not perform
  # its fallback npm install/retries or resolve an unlocked plugin dependency set.
  Push-Location (Join-Path $sourceRoot '@omniroute/opencode-plugin')
  try { Invoke-Checked $node @($npm,'ci','--include=dev','--legacy-peer-deps','--no-audit','--no-fund') } finally { Pop-Location }
  Invoke-Checked 'python' @($helper,'verify',$env:RUNNER_TEMP)
  Assert-Resources 'before-full-next-build' $config.minBuildDiskGiB
  # Installation is complete. A missing build tool must not fetch a new version.
  $env:npm_config_offline = 'true'
  Invoke-Checked $node @($npm,'run','build')
  if (!(Test-Path -LiteralPath (Join-Path $sourceRoot '.build/next/standalone/server.js'))) { throw 'Full standalone missing; do not let build:cli trigger a second build' }
  Invoke-Checked $node @($npm,'run','build:cli')
  Invoke-Checked $node @('scripts/build/write-build-sha.mjs')
  Invoke-Checked 'python' @($helper,'verify',$env:RUNNER_TEMP)
  Invoke-Checked 'python' @($helper,'package',$env:RUNNER_TEMP)
} finally { Pop-Location }
Write-Output "Lab files prepared at $outputRoot; deployment is not performed and runtime acceptance remains pending."
